<?php return array (
  'name' => '默认主题',
  'author'=>'dada123',
  'type'=>'pc',
  'version'=>'1.0'
);
